VERSION = "3.20.0"

if __name__ == "__main__":
    print(VERSION, end="")  # noqa: T201
